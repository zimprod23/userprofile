<?php
// Include config file
require_once "../config.php";

$sql = "SELECT * FROM acheteurs";

if($result = mysqli_query($conn, $sql)){
    echo "<table>
    <caption>Acheteurs</caption>
    <thead>
        <tr>
            <th>acheteur</th>
            <th>Nom</th>
            <th>Compte</th>
            <th>Edit</th>
        </tr>
    </thead>
    <tbody>";

    if(mysqli_num_rows($result) > 0){
        while($row = mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td>" . $row['id_acheteur'] . "</td>
          <td>" . $row['Nom'] . "</td>
          <td>" . $row['Compte'] . "</td>
          <td><a href='FormAcheteur.php?id=" . $row['id_acheteur'] . "'>Update</a>
          <a href='javascript:Delete(".$row['id_acheteur'].")'>Delete</a></td>";
            echo "</tr>";
        }
        echo "</tbody>";
        echo "</table>";
        // Free result set
        mysqli_free_result($result);
    } else{
        echo "<tr>";
        echo "<td colspan='5'>La table est vide</td>";
        echo "</tr>";    }
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
}

// Close connection
mysqli_close($conn);


echo "
    </tbody>
</table>
<div id='btn-add-container'>
<button onclick=\"window.location ='FormAcheteur.php'\">Insérer un acheteur</button>
</div>";
?>

<script>
    function Delete(id){
        if(confirm("voulez vous supprimer l'acheteur id = " + id)){
            window.location = "../Acheteurs/DeleteAcheteur.php?id="+id
        }
    }
</script>

