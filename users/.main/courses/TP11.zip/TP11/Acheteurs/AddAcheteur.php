<?php

if (isset($_POST['nom']) && isset($_POST['compte'])
    && !empty($_POST['nom']) && !empty($_POST['compte'])) {

    require_once "../config.php";

    if (!is_numeric($_POST['compte'])) {
        header("location: ../Pages/FormAcheteur.php?error=Nan");
        exit();
    }

    // Check input errors before inserting in database
    // Prepare an insert statement
    $sql = "INSERT INTO acheteurs(Nom, Compte) VALUES (?, ?)";

    if ($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "si", $param_name, $param_compte);

        $param_name = $_POST['nom'];
        $param_compte = $_POST['compte'];

        if (mysqli_stmt_execute($stmt)) {
            header("location: ../Pages/Acheteurs.php");
        }
        mysqli_stmt_close($stmt);
    }
    mysqli_close($conn);

} else {
    header("location: ../Pages/FormAcheteur.php?error=CompleteAllRecord");
    exit();
}