<?php

if (isset($_POST['nom']) && !empty($_POST['compte'])
    && isset($_POST['compte']) && !empty($_POST['nom'])
    && isset($_POST['id']) && !empty($_POST['id'])) {
    echo "1";

    require_once "../config.php";

    if (!is_numeric($_POST['compte'])){
        header("location: ../Pages/FormAcheteur.php?error=Nan");
        exit();
    }
    $sql = "update acheteurs set Nom=?, Compte=? where id_acheteur=?";

    if ($stmt = mysqli_prepare($conn, $sql)) {
        echo (2);

        mysqli_stmt_bind_param($stmt, "sii", $param_name, $param_compte, $param_id);

        $param_name = $_POST['nom'];
        $param_compte = $_POST['compte'];
        $param_id = $_POST['id'];
        echo "3";

        if (mysqli_stmt_execute($stmt)) {
            echo "4";
            header("location: ../Pages/Acheteurs.php");
        }
        mysqli_stmt_close($stmt);
        echo "5";

    }

    mysqli_close($conn);
}else{
    header("location: ../Pages/FormAcheteur.php?error=CompleteAllRecord");
    exit();
}

