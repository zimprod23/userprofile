<?php
// Include config file
require_once "../config.php";

$sql = "SELECT * FROM produits";

if($result = mysqli_query($conn, $sql)){
    echo "
<table>
    <caption>Produits</caption>
    <thead>
    <tr>
        <th>produit</th>
        <th>Libellé</th>
        <th>Prix</th>
    </tr>
    </thead>
    <tbody>";

    if(mysqli_num_rows($result) > 0){
        while($row = mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td>" . $row['id_produit'] . "</td>
          <td>" . $row['Libelle'] . "</td>
          <td>" . $row['Prix'] . "</td>";
            echo "</tr>";
        }
        echo "</tbody>";
        echo "</table>";
        // Free result set
        mysqli_free_result($result);
    } else{
        echo "<tr>";
        echo "<td colspan='5'>La table est vide</td>";
        echo "</tr>";    }
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
}

// Close connection
mysqli_close($conn);

echo "
    </tbody>
</table>";

