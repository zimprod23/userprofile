<?php
header("location: Pages/Acheteurs.php");