<?php
// Include config file
require_once "../config.php";

$sql = "SELECT * FROM achats";

if($result = mysqli_query($conn, $sql)){
    echo "<table>
    <caption>Achats</caption>
    <thead>
    <tr>
        <th>achat</th>
        <th>acheteur</th>
        <th>produit</th>
    </tr>
    </thead>
    <tbody>";

    if(mysqli_num_rows($result) > 0){
        while($row = mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td>" . $row['id_achat'] . "</td>
          <td>" . $row['id_acheteur'] . "</td>
          <td>" . $row['id_produit'] . "</td>";
            echo "</tr>";
        }
        echo "</tbody>";
        echo "</table>";
        // Free result set
        mysqli_free_result($result);
    } else{
        echo "<tr>";
        echo "<td colspan='5'>La table est vide</td>";
        echo "</tr>";    }
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
}

// Close connection
mysqli_close($conn);

echo "
    </tbody>
</table>";