<?php
include_once "../config.php";
$flag = (isset($_GET['id']) && !empty($_GET['id'])) ? true : false;
if ($flag){
    $sql = "select * from acheteurs where id_acheteur= ".$_GET['id'];
    $acheteur = mysqli_fetch_array(mysqli_query($conn, $sql));
    mysqli_close($conn);
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Super Marcher</title>
    <link href="../style.css" rel="stylesheet" type="text/css">
    <style>

    </style>
</head>

<body>
<?php include '../Pages/navbar.html'?>
    <div class="container">
        <?php
        if (isset($_GET['error']) && $_GET['error'] == 'CompleteAllRecord')
            echo "<div style='color: red; font: 20px \"Times New Roman\", sans-serif'> Complet All Record First</div>";
        else if (isset($_GET['error']) && $_GET['error'] == 'Nan')
            echo "<div style='color: red; font: 20px \"Times New Roman\", sans-serif'> Le Compte n'est pas un nombre</div>"
        ?>

        <form method="post"
              action="<?php echo $flag ? '../Acheteurs/UpdateAcheteur.php' : '../Acheteurs/AddAcheteur.php' ?>">
            <input type="hidden" name="id" value="<?php echo $flag ? $acheteur['id_acheteur']: null ?> ">

            <div class="row">
                <div class="col-25">
                    <label for="nom">Nom : </label>
                </div>
                <div class="col-75">
                    <input id="nom" name="nom" type="text" required value="<?php echo $flag ? $acheteur['Nom'] : null ?>">
                </div>
            </div>
            <div class="row">
                <div class="col-25">
                    <label for="compte">Compte : </label>
                </div>
                <div class="col-75">
                    <input id="compte" name="compte" type="number" required
                           value="<?php echo $flag ? $acheteur['Compte'] : null ?>"></div>
            </div>
            <div class="row">
                <button type="submit">Ok</button>
                <button type="reset">Annuler</button>
            </div>
        </form>
    </div>
</body>
</html>