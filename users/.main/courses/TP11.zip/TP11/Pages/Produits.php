<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Super Marcher</title>
    <link href="../style.css" type="text/css" rel="stylesheet"/>
</head>

<body>

<header>
    <?php include_once "navbar.html" ?>
</header>

<main>
    <?php include_once "../Produits/SelectAllProduits.php" ?>
</main>

</body>
</html>