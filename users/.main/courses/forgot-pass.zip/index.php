<?php
include 'config.php';
?>
<!DOCTYPE HTML>
<html>
<head>
    <title>How to create forget password recovery procedure in PHP by Codepress</title>
</head>
<body>
	<h2>Reset Password</h2>
	<?php
	if (isset($_POST['email']) && ($_POST['email']!="")) {
		# code...
		$email=trim($_POST['email']); // get email address from user form
		$code=md5(uniqid(true)); // random alphernumeric character store in $code variable
		
		if (!filter_var($email, FILTER_VALIDATE_EMAIL) === false) {

			$checkmail=$db->query("SELECT email FROM users WHERE email='$email' ") or die(mysqli_error('Run time error...'));
			$count=mysqli_num_rows($checkmail); // check if user is on our data base

			if ($count==1) { // if email is stored in our database update lost password field with random code for reset
				# code...s
				$inserted=$db->query("UPDATE users SET lost='$code' WHERE email='$email' ");
  				// update our table users with unique random code
  				/* Send a link to reset password */
				  $to = $email;
				  $subject = "reset password link";
				  $header = "By codexpress";
				  $body = "here is your link to reset your password
				  For active your account, visit the link below to complete : 
				  http://www.thewallclone.com/updatepassword.php?email=$email&code=$code";

				  $sent=mail($to,$subject,$body,$header);
  				
  					# code...
				if ($inserted) { /* update is successfull */
					# code...
					echo("Check your mail we have sent you reset link to change your password! <br>");

				}
			}
			else
			{
				 echo("Oops! Sorry, $email dose not belong to any account!");
			}

		} else {
		  echo("$email is not a valid email address");
		}
	}
	$db->close();
	?>
    <form method="post" action="#">
    
        <p><label>Email: </label><input type="text" name="email" /></p>
        <p><input type="submit" name="submit" value="Reset"/></p>
    </form>
</body>
</html>